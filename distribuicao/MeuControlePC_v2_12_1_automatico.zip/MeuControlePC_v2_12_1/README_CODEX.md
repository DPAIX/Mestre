# MeuControlePC v2.12.1 — Projeto para Codex

Este pacote contém o código-fonte, documentação, testes e instruções do Codex (`AGENTS.md`). Os arquivos `dados_iniciais/` são exemplos genéricos. O pacote de distribuição exclui `.env`, dados pessoais, credenciais, ambientes virtuais e modelos.

Correção v2.12.1: [respostas utilizáveis e conversa em texto simples](REVISAO_V2_12_1.md). Formato inválido não conta como sucesso da equipe; a pergunta sobre capacidades recebe resposta local.

Novidade v2.12.0: [equipe com orçamento por modelo e conversa por texto/áudio com esclarecimentos](REVISAO_V2_12_0.md). Basta pedir em linguagem comum; tarefas incompletas geram perguntas e ações continuam sujeitas a confirmação.

Novidade v2.11.4: [estado observado do Telegram no painel e no /status](REVISAO_V2_11_4.md), com idade da última consulta, falhas e recuperação, sem chamadas extras. A atualização completa preserva configuração, dados, modelos e rede.

Correção v2.11.3: [conexão IPv6 e reinício do 9Remote](REVISAO_V2_11_3.md). O [reparo separado](REPARO_9REMOTE.md) corrige os bundles gerenciados exatos com backup e abre o painel do host, sem reinstalar o bot.

Ferramentas separadas: [diagnóstico do acesso ao Telegram por duplo clique](DIAGNOSTICO_TELEGRAM.md) e [teste reversível da detecção automática de proxy do Windows](TESTE_PROXY_WINDOWS.md). Os pacotes próprios ficam em `distribuicao/`; não exigem reinstalar o assistente. O diagnóstico não valida o token do bot nem envia mensagens. O teste de proxy atua somente na opção indicada, com backup e restauração, e precisa de conferência no PC.

Se o teste retornar `inalterado`, use o [reparo específico do hosts e diagnóstico do Windows](REPARO_HOSTS_E_DIAGNOSTICO.md). A correção de hosts libera somente `wl.spotify.com`; a sonda de proxy localiza a etapa que não responde, e as sondas NCSI comparam o acesso público por IPv4 e IPv6. O arquivo hosts privado não é distribuído.

Correção v2.11.2: [painel do host 9Remote e progresso da preparação](REVISAO_V2_11_2.md). O painel local do host é http://127.0.0.1:2208/ui/index.html.

Correção v2.11.1: [início do Ollama e retomada](REVISAO_V2_11_1.md). Para atualizar uma preparação ainda aberta, feche primeiro o console que mostra **Preparação automática: http://127.0.0.1:...**; depois abra o iniciador do pacote novo.

## Instalação no Windows em um clique

Extraia o pacote completo em Downloads, fora da pasta instalada, e abra **`INSTALAR_E_INICIAR.bat`**. O iniciador confere e implanta as fontes em C: com backup, reaproveita a configuração e os dados externos, prepara os componentes faltantes e solicita o início do assistente. O `iniciar_redirecionado.bat`, sem argumentos, também usa esse fluxo.

A janela local começa a preparação automaticamente. Ela oferece somente as pendências de conta e o botão **Retomar**. O 9Router pode criar sua nova chave dedicada pela autenticação oficial da CLI existente; login, 2FA, CAPTCHA e consentimentos ainda são concluídos pelo proprietário. Chaves são salvas apenas pelo campo oculto local, sem devolução ao chat ou à página de estado.

Consulte [Instalação automática](GUIA_INSTALACAO_AUTONOMA.md) para os caminhos, contas, conferência no PC e reversão. [A revisão v2.11.0](REVISAO_V2_11_0.md) descreve a implementação e os limites da validação. RoboTask é detectado sem executar tarefas desconhecidas; a nuvem não acessa o Windows apenas por ele estar instalado.

## Usar no Codex desktop ou CLI (Windows)
1. Descompacte a pasta do projeto (não sobrescreva sua instalação em funcionamento).
2. Abra a pasta `MeuControlePC_Codex` no Codex desktop, VS Code com Codex ou no terminal do Codex.
3. Peça: `Leia AGENTS.md, execute os testes e faça uma auditoria de segurança e estabilidade sem alterar credenciais nem dados.`
4. Use um diretório de trabalho/branch separado para testar mudanças antes de atualizar a instalação real.

## Usar no Codex Cloud (GitHub)
1. Crie um **repositório privado** no GitHub, sem inicializar README (o pacote já contém arquivos).
2. Coloque o conteúdo da pasta na raiz do repositório, com `.gitignore`, `.env.exemplo`, `AGENTS.md` e `testes/`. Não inclua `.env`, `dados/`, `token.json` ou `credentials.json`.
3. Para publicar usando Git (instalado e autenticado):

   ```powershell
   cd C:\CAMINHO\MeuControlePC_Codex
   git init
   git add .
   git status --short
   git commit -m "Importar fontes publicas do MeuControlePC"
   git branch -M main
   git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
   git push -u origin main
   ```

4. Abra https://chatgpt.com/codex (ou o Codex desktop), conecte o repositório GitHub ao **ambiente Codex Cloud** e publique o ambiente seguindo as instruções do produto.
5. Sem Windows/RoboTask, use a nuvem para análise, documentação e testes unitários. Valide ações de GUI e hotkeys no seu PC, sob supervisão.

## Testes sem segredos

```powershell
python -m unittest discover -s testes -v
   python -m compileall -q .
```

Opcional: `python -m pip install -r requirements.txt` no ambiente Windows, para testar a interface. O CI executa somente testes locais e não faz chamadas a Telegram nem serviços de IA.

## Arquitetura resumida

| Arquivo | Função |
|---|---|
| `assistente_pc.py` | Interface Telegram e comandos |
| `saude_telegram.py` | Estado em memória das consultas existentes ao Telegram |
| `nucleo.py` | Dados JSON, logs, migração e rotinas |
| `multi_ia.py` | Provedores, erros e cotas |
| `evolucao_segura.py` | Autoanálise e melhorias com backup |
| `reinicio_seguro.py` | Reinício do assistente e reinício condicionado do Windows |
| `automacao_pc.py` | Ações locais com confirmação |
| `ponte_robotask.py` | Catálogo RoboTask |
| `painel_rotina.html` | Painel local |
| `preparacao_autonoma.py` | Preparação com progresso e pendências locais |
| `implantacao_assistente.py` | Implantação de fontes verificadas com backup |
| `configurar_gateway_automatico.py` | Configuração local pela API oficial 9Router |

## Atenção
- Não publique `.env`, backups privados ou dados pessoais ao atualizar o repositório. O manifesto público enumera somente arquivos distribuíveis.
- As chaves antigas presentes no projeto legado foram expostas anteriormente: **revogue-as e crie outras**, mantendo-as apenas no seu `.env` local.
- GitHub Actions não é uma prova de funcionamento no Windows real com RoboTask e Telegram.

**Documentação:** https://help.openai.com/pt-br/articles/20001545-using-codex-cloud
